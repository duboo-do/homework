/***********************************************
소스코드 관리하기
***********************************************/
#include <stdio.h>
#include "calculator.h"

int main(){
    
    //printf("%d", add(10,20));
    //printf("%d", sub(10,20));
    //printf("%d", multi(10,20));
    printf("%d", printAdd(10,20));
    return 0;
}